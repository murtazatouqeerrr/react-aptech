import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Login() {

  const navigate = useNavigate();   // ✅ correct place for hook

  const [user, setUser] = useState({
    email: "",
    password: ""
  });

  const handleInput = (e) => {
    const { name, value } = e.target;
    setUser({
      ...user,
      [name]: value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const query = new URLSearchParams({
      email: user.email,
      password: user.password
    }).toString();

    const response = await fetch(`http://localhost:8000/login?${query}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json"
      }
    });

    const respData = await response.json();

    if (response.ok) {
      alert(respData.msg);

      // 🔥 CORRECT REDIRECT
      navigate("/");
      
    } else {
      alert("login failed: " + respData.msg);
    }
  };

  return (
    <>
      <div>
        <h1>Welcome to Login page</h1>
      </div>

      <form onSubmit={handleSubmit}>
        <input
          type='text'
          name='email'
          value={user.email}
          placeholder='Enter Email'
          onChange={handleInput}
        />
        <input
          type='password'
          name='password'
          value={user.password}
          placeholder='Enter Password'
          onChange={handleInput}
        />
        <input type='submit' value='Submit' />
      </form>
    </>
  );
}

export default Login;
